    1  sudo apt-get update -y
    2  exit
    3  ls
    4  cd app
    5  ls
    6  cd environment/
    7  ls
    8  cd app
    9  ls
   10  nano provision.sh 
   11  cd ..
   12  ls
   13  cd db
   14  ls
   15  nano provision.sh 
   16  cd ..
   17  ls
   18  cd ..
   19  ls
   20  cd app
   21  ls
   22  npm install 
   23  cd ..
   24  cd environment/
   25  ls
   26  cd db/
   27  ls
   28  cd db
   29  ls
   30  chmod +x provision.sh 
   31  ls
   32  ./provision.sh 
   33  sudo systemctl status mongodb
   34  ls
   35  nano provision.sh 
   36  cd ..
   37  ls
   38  cd db
   39  ls
   40  sudo nano provision.sh 
   41  sudo ./provision.sh 
   42  sudo systemctl status mongodb
   43  nano provision.sh 
   44  sudo systemctl status mongod
   45  sudo systemctl start mongod
   46  sudo systemctl status mongod
   47  rm -rf provision.sh 
   48  ls
   49  sudo nano provision.sh
   50  chmod +x provision.sh 
   51  sudo chmod +x provision.sh 
   52  sudo ./provision.sh 
   53  ls 
   54  ./provision.sh
   55  nano provision.sh
   56  sudo nano provision.sh
   57  ./provision.sh
   58  sudo systemctl status mongod
   59  sudo apt-get install dos2unix
   60  dos2unix provisions.sh
   61  dos2unix provision.sh
   62  sudo dos2unix provision.sh
   63  ./provision.sh
   64  sudo apt-get update -y
   65  ls
   66  cd ..
   67  ls
   68  exit
   69  ls
   70  sudo systemctl status nignx
   71  sudo apt-get update -y
   72  sudo apt-get install nginx -y
   73  sudo systemctl status nignx
   74  sudo systemctl status nginx
   75  ls
   76  cd app
   77  ls
   78  cd app
   79  cd ..
   80  cd environment/
   81  ls
   82  cd ap
   83  cd app
   84  ls
   85  nano provision.sh 
   86  sudo ./provision.sh 
   87  ls
   88  cd ..
   89  ls
   90  cd app
   91  ls
   92  cd ..
   93  ls
   94  cd ..
   95  ls
   96  cd ap
   97  cd app
   98  ls
   99  sudo npm install
  100  ls
  101  sudo npm start
  102  ls
  103  cd ..
  104  ls
  105  dc environment/
  106  ls
  107  cd environment/
  108  ls
  109  cd db/
  110  ls
  111  sudo nano provision.sh 
  112  sudo naon mongod.conf 
  113  sudo nano mongod.conf 
  114  ls
  115  cd ..
  116  ls
  117  cd app
  118  ls
  119  sudo nano provision.sh 
  120  pwd
  121  sudo nano provision.sh 
  122  ls
  123  nano nginx.default 
  124  ./provision.sh 
  125  ls
  126  cd ..
  127  ls
  128  cd ..
  129  ls
  130  cd app
  131  ls
  132  npm start
  133  ls
  134  cd ..
  135  ls
  136  cd /etc
  137  ls
  138  cd nginx/
  139  ls
  140  nano nginx.conf 
  141  clera
  142  ls
  143  clear
  144  ls
  145  cd sites-
  146  cd sites-available/
  147  ls
  148  cd ..
  149  cd sites-enabled/
  150  ls
  151  cd def
  152  cd default
  153  ls
  154  ls -a
  155  ls
  156  cd default
  157  ls
  158  clear
  159  ls
  160  cd ..
  161  cd nginx/
  162  ls
  163  sudo nano nginx.conf 
  164  sudo systemctl restart nginx
  165  sudo systemctl status nginx
  166  sudo systemctl reload nginx
  167  sudo systemctl start nginx
  168  sudo nano nginx.conf 
  169  sudo systemctl start nginx
  170  sudo systemctl reload nginx
  171  ls
  172  cd sites-available/
  173  ls
  174  cd ..
  175  ls
  176  cd ..
  177  ls
  178  cd ..
  179  ls
  180  cd app
  181  ls
  182  cd home/
  183  ls
  184  cd ubuntu/
  185  ls
  186  cd app
  187  ls
  188  cd environment/
  189  cd app
  190  ls
  191  nano provision.sh 
  192  sudo nano nginx.default 
  193  ./provision.sh 
  194  sudo apt-get remove nginx
  195  ls
  196  ./provision.sh 
  197  sudo service nginx stop
  198  sudo service nginx start
  199  udo apt-get remove nginx nginx-common
  200  sudo apt-get remove nginx nginx-common
  201  sudo apt-get purge nginx nginx-common
  202  sudo apt-get autoremove
  203  rm -rf /etc/nginx
  204  cd ..
  205  ls
  206  sudo apt-get install nginx -y
  207  sudo systemctl start nginx
  208  sudo systemctl enable nginx
  209  systemctl status nginx
  210  ls
  211  cd app
  212  ls
  213  pwd
  214  sudo nano provision.sh
  215  sudo ./provision.sh
  216  sudo chmod +x provision.sh
  217  sudo ./provision.sh
  218  sudo systemctl enable nginx
  219  sudo systemctl reload nginx
  220  ls
  221  cd app
  222  ls
  223  npm start
  224  cd ~/nginx
  225  cd ..
  226  ls
  227  cd /etc
  228  cd /nginx
  229  ls
  230  cd nginx
  231  ls
  232  cd sites-available/
  233  ls
  234  nano default 
  235  rm default 
  236  ls
  237  rm default 
  238  ls
  239  rm -rf default 
  240  ls
  241  sudo rm -rf default 
  242  ls
  243  sudo nano default
  244  sudo nginx -t
  245  sudo nano default
  246  sudo nginx -t
  247  ls
  248  cd ~/app
  249  ls
  250  cd app
  251  npm start
  252  sudo npm start
  253  cd ..
  254  ls
  255  cd ..
  256  ls
  257  cd ubuntu/
  258  ls
  259  cd app
  260  ls
  261  sudo nano jenkins_provision.sh
  262  chmod +x jenkins_provision.sh 
  263  sudo chmod +x jenkins_provision.sh 
  264  sudo ./jenkins_provision.sh 
  265  exit
  266  systemctl status mongod
  267  systemctl start mongod
  268  sudo systemctl start mongod
  269  sudo systemctl status mongod
  270  export DB_HOST="mongodb://34.245.144.104:27017/posts"
  271  export DB_HOST="mongodb://54.78.21.145/:27017/posts"
  272  sudo systemctl status mongod
  273  sudo systemctl restart mongod
  274  sudo systemctl status mongod
  275  sudo systemctl reload mongod
  276  cd /etc
  277  ls 
  278  sudo nano mongod.conf
  279  sudo chmod 600 mongod.conf
  280  sudo chmod 700 mongod.conf
  281  rm -rf mongod.conf
  282  sudo rm -rf mongod.conf
  283  sudo nano mongod.conf
  284  sudo systemctl restart mongod
  285  sudo systemctl status mongod
  286  cd nginx/
  287  ls
  288  cd sites-available/
  289  ls
  290  sudo nano default 
  291  sudo nginx -t
  292  sudo nano default 
  293  sudo nginx -t
  294  sudo systemctl restart nginx
  295  cd ~/app
  296  ls
  297  cd app/
  298  ls
  299  sudo npm start
  300  env
  301  unset DB_HOST=mongodb://54.78.21.145/:27017/posts
  302  sudo unset DB_HOST=mongodb://54.78.21.145/:27017/posts
  303  sudo unset DB_HOST
  304  unset DB_HOST
  305  env
  306  export DB_HOST=mongodb://34.244.159.59/:27017/posts
  307  env
  308  ls
  309  npm start
  310  sudo npm start
  311  env
  312  unset DB_HOST
  313  export DB_HOST="mongodb://34.245.144.104:27017/posts"
  314  unset DB_HOST
  315  export DB_HOST="mongodb://34.244.159.59:27017/posts"
  316  clear
  317  env
  318  sudo npm start
  319  exit
  320  cd app
  321  ls
  322  sudo npm start
  323  env
  324  export DB_HOST=mongodb://34.244.159.59:27017/posts
  325  sudo npm start
  326  cd ~/etc/nginx
  327  cd ~/etc
  328  cd ..
  329  ls
  330  cd /et
  331  cd /etc/
  332  cd nginx/
  333  ls
  334  cd sites-available/
  335  ls
  336  sudo nano default 
  337  clear
  338  env
  339  reboot
  340  sudo reboot
  341  env
  342  export DB_HOST=mongodb://34.244.159.59:27017/posts
  343  env
  344  cd app
  345  .s
  346  ls
  347  cd app
  348  ls
  349  sudo npm start
  350  ls
  351  exit
  352  ls
  353  exit
  354  ls
  355  sudo apt-get install pip
  356  sudo apt-get install python-pip
  357  sudo pip install flask
  358  ls
  359  cd mvc
  360  ls
  361  cd FinalProject_App-master/
  362  ls
  363  pip install .
  364  ls
  365  cd Flask/
  366  ls
  367  sudo flask run
  368  cd ~app
  369  cd ~/app
  370  ls
  371  cd app
  372  sudo npm start
  373  cd ~/nginx
  374  cd ..
  375  ls
  376  cd /etc/
  377  cd nginx
  378  ls
  379  cd sites-available/
  380  ls
  381  sudo nano default 
  382  sudo nginx -t
  383  systemctl restart nginx
  384  sudo systemctl restart nginx
  385  sudo systemctl status nginx
  386  sudo systemctl reload nginx
  387  sudo systemctl status nginx
  388  cd ~/app
  389  cd ..
  390  cd mvc
  391  ls
  392  cd FinalProject_App-master/
  393  ls
  394  sudo apt-get update -y
  395  cd Flask/
  396  sudo flask run
  397  set FLASK_ENV=development
  398  flask run
  399  pip freeze
  400  pip freeze >> requirement.txt
  401  ls
  402  cd ..
  403  cd FinalProject_App-master/
  404  ls
  405  cd Flask/
  406  ls
  407  virtualenv virt
  408  sudo apt-get install virtualenv
  409  virtualenv virt
  410  pip install setuptools
  411  flask run
  412  clera
  413  clear
  414  ls
  415  cd virt/
  416  ls
  417  cd bin
  418  ls
  419  cd ..
  420  buntu@ip-172-31-1-252:~/mvc/FinalProject_App-master/Flask$ ls
  421  app.py  app.pyc  Downloads  __pycache__  requirement.txt  static  templates  virt
  422  ubuntu@ip-172-31-1-252:~/mvc/FinalProject_App-master/Flask$ cd virt/
  423  ubuntu@ip-172-31-1-252:~/mvc/FinalProject_App-master/Flask/virt$ ls
  424  bin  include  lib  local  pip-selfcheck.json  share
  425  ubuntu@ip-172-31-1-252:~/mvc/FinalProject_App-master/Flask/virt$ cd bin
  426  ubuntu@ip-172-31-1-252:~/mvc/FinalProject_App-master/Flask/virt/bin$ ls
  427  activate      activate.fish     easy_install      pip   pip2.7  python2    python-config
  428  activate.csh  activate_this.py  easy_install-2.7  pip2  python  python2.7  wheel
  429  ubuntu@ip-172-31-1-252:~/mvc/FinalProject_App-master/Flask/virt/bin$ cd ..
  430  ubuntu@ip-172-31-1-252:~/mvc/FinalProject_App-master/Flask/virt$ cd ..
  431  ubuntu@ip-172-31-1-252:~/mvc/FinalProject_App-master/Flask$
  432  source virt/bin/activate
  433  flast run
  434  flask run
  435  pip install flask==1.0.2
  436  flask run
  437  sudo apt-get update -y
  438  flask run
  439  ls
  440  python app.py
  441  ls
  442  cd ..
  443  ls
  444  sudo docker build -t ahskhan/ITjobswatch .
  445  sudo docker install docker.io
  446  histroy >> setup_python_env_ec2.md
  447  history >> setup_python_env_ec2.md
