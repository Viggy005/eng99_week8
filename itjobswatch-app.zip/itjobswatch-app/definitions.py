import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

TEST_RESOURCES_FOLDER = ROOT_DIR + '/tests/test_resources'

if __name__ == '__main__':
    print(ROOT_DIR)
