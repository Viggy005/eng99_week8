from setuptools import setup

setup(
    name='itjobswatch_data',
    version='0.1',
    packages=[''],
    url='',
    license='',
    author='kierancornwall',
    author_email='kcornwall@spartaglobal.com',
    description='',
    install_requires=['pytest', 'requests', 'beautifulsoup4']
)